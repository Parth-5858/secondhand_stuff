<?php
include("connect.php");

date_default_timezone_set('Asia/Kolkata');

switch($_REQUEST['action'])
{
	case "product_listing":
		product_listing();
		break;
	case "view_home_slider":
		view_home_slider();
		break;
	
	
}
function fun404()
{
header('http://mitaljewels.com/ITficial/mj/mjmin/dashboard.php');
}
function product_listing(){
	global $link;
	global $web;
	
	$catid=$_REQUEST['cat'];
	$catname=$_REQUEST['catname'];
	
	$sql=mysqli_query($link,"select * from products where sub_category_id='".$catid."'");
	while($catdata=mysqli_fetch_array($sql)){
		//get product image
		$pimgsql=mysqli_query($link,"select * from product_images where itype='1' and pid='".$catdata['product_id']."'");
		$pimgdata=mysqli_fetch_assoc($pimgsql);
		if(mysqli_num_rows($pimgsql)>0){
			$proimg=$web.'product_images'.$pimgdata['name'];
		}
		else{
			$proimg=$web.'images/logo.png';
		}
		
		if($catdata['gold_price']!=''){
			$price='<i class="fa fa-rupee"></i> '.$catdata['gold_price'];
		}
		else{
			$price='<i class="fa fa-rupee"></i> 100';
		}
		
		$datas .='<li>
					<div class="product-div">
						<div class="product-img">
							<img src="'.$proimg.'">
							<div class="hover-img animate"><img  class="animate" src="'.$proimg.'"></div>
							<a href="javascript:void(0)" class="quick-view">
								<i class="fa fa-eye"></i>
								quick view
							</a>
							
						</div>
						<div class="product-info">
							<div class="product-name1">'.$catname.'</div>
							<div class="disc">'.$catdata['product_name'].'</div>
							<div class="prodcut-price">'.$price.'</div>
							<a href="'.$web.'product-detail.php/'.seo_friendly_url($catname).'/'.seo_friendly_url($catdata['product_name']).'/'.base64_encode($catdata['product_id']).'" class="option-btn animate">select option</a>
						</div>
					</div>
				</li>';
	}
	echo $datas;
}
function view_home_slider(){
	global $link;
	global $web;
	
	$sql=mysqli_query($link,"select * from images");
	while($row=mysqli_fetch_array($sql)){
		$data .='<div class="item">

						<div class="post-box">

							<img src="'.$row['name'].'" alt="Slider" />

							<div class="entry-content">

								<span class="post-category"><a href="#" title="Travel">Lifestyle</a></span>

								<h3><a href="#" title="Great Himalaya Trails, Trekking, Hiking and Walking in Nepal">Great Himalaya Trails, Trekking, Hiking and Walking in Nepal</a></h3>

								<a href="#" title="Read More">Read More</a>

							</div>

						</div>

					</div>'; 
	} 
	echo $data;
}



?>
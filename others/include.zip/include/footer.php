	<!-- JQuery v1.12.4 -->
	<script src="<?php echo $web1; ?>assets/js/jquery-1.12.4.min.js"></script>

	<!-- Library - Js -->
	<script src="<?php echo $web1; ?>assets/js/popper.min.js"></script>
	<script src="<?php echo $web1; ?>assets/js/lib.js"></script>
	<script type="text/javascript" src="<?php echo $web1; ?>assets/slick/slick.min.js"></script>
	
	<!-- Library - Theme JS -->
	<script src="<?php echo $web1; ?>assets/js/functions.js"></script>	
	<script src="<?php echo $web1; ?>scroll-bar/smooth-scroll.min.js"></script>
	<script src="<?php echo $web1; ?>script.js"></script>

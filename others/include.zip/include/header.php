<head>

	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

	<title>MTJ World</title>

	
	<!-- Standard Favicon -->
	<link rel="icon" type="image/x-icon" href="<?php echo $web1; ?>images/favicon.ico" />

	<!-- For iPhone 4 Retina display: -->
	<link rel="apple-touch-icon-precomposed" href="http://atixscripts.info/demo/html/minimag/assets/images//apple-touch-icon-114x114-precomposed.png">

	<!-- For iPad: -->
	<link rel="apple-touch-icon-precomposed" href="http://atixscripts.info/demo/html/minimag/assets/images//apple-touch-icon-72x72-precomposed.png">

	<!-- For iPhone: -->
	<link rel="apple-touch-icon-precomposed" href="http://atixscripts.info/demo/html/minimag/assets/images//apple-touch-icon-57x57-precomposed.png">

	<!-- Library - Google Font Familys -->
	<link href="https://fonts.googleapis.com/css?family=Hind:300,400,500,600,700%7cMontserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

	<!-- Library -->
    <link href="<?php echo $web1; ?>assets/css/lib.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo $web1; ?>assets/slick/slick.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $web1; ?>assets/slick/slick-theme.css">

	<!-- Custom - Common CSS -->
	<link rel="stylesheet" href="<?php echo $web1; ?>assets/css/rtl.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $web1; ?>assets/style.css">
	<link rel="stylesheet" href="<?php echo $web1; ?>animate-css/animate.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $web1; ?>customcss.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
	
</head>


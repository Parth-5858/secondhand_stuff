
<header>
  <div class="cust-nav inner-header detail-heder">
      <div class="top-strip clearfix">
        <div class="top-strip-left">
            <ul>
              <li>
                  <a href="javascript:void(0)">NEED HELP?1-800-123-45-67</a>
              </li>
            </ul>
        </div>
        <div class="top-strip-right">
          <ul>
            <li>
                <a href="javascript:void(0)">contact</a>
            </li>
            <li>
                <a href="javascript:void(0)"> logIn / Register </a>
            </li>
            <li>
                <a href="javascript:void(0)"> <i class="fa fa-facebook"></i></a>
            </li>
            <li>
                <a href="javascript:void(0)"><i class="fa fa-twitter"></i></a>
            </li>
            <li>
                <a href="javascript:void(0)"><i class="fa fa-instagram"></i></a>
            </li>  
          </ul>
        </div>
    </div>
	
    <div class="main-hed clearfix animate">
      <div class="logo pull-left">
          <a href="javascript:void()"><img src="<?php echo $web;?>images/logo.png"></a>
      </div>
      <div class="header-menu pull-left">
        <ul>
          <li><a href="javascript:void()">home</a></li>
          <li><a href="javascript:void()">jewels</a> </li>
          <li><a href="javascript:void()">couture</a> </li>
          <li><a href="javascript:void()">collection</a> </li>
          <li><a href="javascript:void()">Contact us</a> </li>
        </ul>
      </div>
	  <div class="header-search pull-right">

			<a href="javascript:void()"><i class="fa fa-search"></i></a>

		</div>
    </div>  

<div class="search-panel clearfix">

            <div class="search-right">

                <div class="search-hed">search 

                    <a href="javascript:void(0)" class="closed-slide"><i class="fa fa-times"></i></a>

                </div>

                

                <div class="search-box">

                    <input type="text" placeholder="Search for :" class="form-control">

                    <a href="javascript:void()"><i class="fa fa-search"></i></a>

                </div>

                <div class="search-box-info">

                    Find your product with fast search. Enter some keyword such as dress, shirts, shoes etc.

                </div>

                <div class="search-featured-product">

                    <div class="search-inn-hed">FEATURED PRODUCTS</div>

                    

                    <div class="search-product-list">

                        <div class="media notif-item">

                            <a href="javascript:void(0)">

                                <div class="media-left">

                                    <div class="notif-pro">

                                    <img src="images/jewellary-item1.png">

                                    </div>	

                                </div>

                                <div class="media-body">

                                    <div class="searh-pro-title">WISTERIA DIAMOND GOLD</div>

                                    <span class="pro-tag">E-024-01</span>

                                    <div class="notif-msg"><i class="fa fa-rupee"></i> 2550</div>

                                </div>

                            </a>    

                        </div>

                        <div class="media notif-item">

                            <a href="javascript:void(0)">

                                <div class="media-left">

                                    <div class="notif-pro">

                                    <img src="images/jewellary-item1.png">

                                    </div>	

                                </div>

                                <div class="media-body">

                                    <div class="searh-pro-title">WISTERIA DIAMOND GOLD</div>

                                    <span class="pro-tag">E-024-01</span>

                                    <div class="notif-msg"><i class="fa fa-rupee"></i> 2550</div>

                                </div>

                            </a>    

                        </div>

                        <div class="media notif-item">

                            <a href="javascript:void(0)">

                                <div class="media-left">

                                    <div class="notif-pro">

                                    <img src="images/jewellary-item1.png">

                                    </div>	

                                </div>

                                <div class="media-body">

                                    <div class="searh-pro-title">WISTERIA DIAMOND GOLD</div>

                                    <span class="pro-tag">E-024-01</span>

                                    <div class="notif-msg"><i class="fa fa-rupee"></i> 2550</div>

                                </div>

                            </a>    

                        </div>

                        <div class="media notif-item">

                            <a href="javascript:void(0)">

                                <div class="media-left">

                                    <div class="notif-pro">

                                    <img src="images/jewellary-item1.png">

                                    </div>	

                                </div>

                                <div class="media-body">

                                    <div class="searh-pro-title">WISTERIA DIAMOND GOLD</div>

                                    <span class="pro-tag">E-024-01</span>

                                    <div class="notif-msg"><i class="fa fa-rupee"></i> 2550</div>

                                </div>

                            </a>    

                        </div>

                    </div>

                    <a href="javascript:void()" class="load-more">load more</a>

                </div>

            </div>

        </div>
	
  </div>
</header> 